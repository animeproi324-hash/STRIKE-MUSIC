package com.strikemusic.player

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.Locale
import java.util.concurrent.Executor

class MainActivity : AppCompatActivity() {
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val handler = Handler(Looper.getMainLooper())
    private val favorites = mutableSetOf<Int>()
    private lateinit var titleText: TextView
    private lateinit var artistText: TextView
    private lateinit var currentTime: TextView
    private lateinit var totalTime: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var playButton: Button
    private lateinit var favButton: Button
    private lateinit var trackList: LinearLayout
    private var userSeeking = false

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        val items = uris.map { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val name = displayName(uri)
            MediaItem.Builder().setUri(uri).setMediaMetadata(
                MediaMetadata.Builder().setTitle(name).setArtist("LOCAL FILE").build()
            ).build()
        }
        val c = controller ?: return@registerForActivityResult
        c.setMediaItems(items)
        c.prepare()
        c.playWhenReady = false
        renderTracks(items.map { it.mediaMetadata.title?.toString() ?: "Audio track" })
        updatePlayerUi()
        Toast.makeText(this, "Добавлено треков: ${items.size}", Toast.LENGTH_SHORT).show()
    }

    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        titleText = findViewById(R.id.titleText)
        artistText = findViewById(R.id.artistText)
        currentTime = findViewById(R.id.currentTime)
        totalTime = findViewById(R.id.totalTime)
        seekBar = findViewById(R.id.seekBar)
        playButton = findViewById(R.id.playButton)
        favButton = findViewById(R.id.favButton)
        trackList = findViewById(R.id.trackList)

        findViewById<Button>(R.id.addButton).setOnClickListener {
            picker.launch(arrayOf("audio/*"))
        }
        playButton.setOnClickListener {
            controller?.let { c ->
                if (c.mediaItemCount == 0) picker.launch(arrayOf("audio/*"))
                else if (c.isPlaying) c.pause() else c.play()
                updatePlayerUi()
            }
        }
        findViewById<Button>(R.id.prevButton).setOnClickListener { controller?.seekToPreviousMediaItem() }
        findViewById<Button>(R.id.nextButton).setOnClickListener { controller?.seekToNextMediaItem() }
        favButton.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            val index = c.currentMediaItemIndex
            if (index >= 0) {
                if (!favorites.add(index)) favorites.remove(index)
                favButton.text = if (favorites.contains(index)) "♥" else "♡"
            }
        }
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) { userSeeking = true }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                userSeeking = false
                controller?.seekTo((seekBar?.progress ?: 0).toLong())
            }
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
        connectController()
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.addListener(object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = updatePlayerUi()
                    override fun onIsPlayingChanged(isPlaying: Boolean) = updatePlayerUi()
                    override fun onPlaybackStateChanged(playbackState: Int) = updatePlayerUi()
                })
                updatePlayerUi()
            } catch (_: Exception) {
                Toast.makeText(this, "Не удалось запустить аудиосервис", Toast.LENGTH_LONG).show()
            }
        }, Executor { it.run() })
    }

    private fun displayName(uri: Uri): String {
        var name = "Audio track"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
        }
        return name.substringBeforeLast(".")
    }

    private fun renderTracks(names: List<String>) {
        trackList.removeAllViews()
        names.forEachIndexed { index, name ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(14, 13, 14, 13)
                setBackgroundColor(if (index % 2 == 0) 0xFF17212B.toInt() else 0xFF10171F.toInt())
                isClickable = true
                isFocusable = true
                setOnClickListener { controller?.seekToDefaultPosition(index); controller?.play(); updatePlayerUi() }
            }
            val icon = TextView(this).apply {
                text = "♫"; textSize = 21f; setTextColor(0xFFFF5A1F.toInt())
                gravity = Gravity.CENTER; width = dp(42); height = dp(42)
            }
            val label = TextView(this).apply {
                text = name; textSize = 13f; setTextColor(0xFFF4F7FB.toInt())
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            }
            row.addView(icon)
            row.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            trackList.addView(row, LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(6) })
        }
    }

    private fun updatePlayerUi() {
        val c = controller ?: return
        val item = c.currentMediaItem
        titleText.text = item?.mediaMetadata?.title ?: "ВЫБЕРИ МУЗЫКУ"
        artistText.text = item?.mediaMetadata?.artist ?: "LOCAL AUDIO • READY"
        playButton.text = if (c.isPlaying) "Ⅱ" else "▶"
        favButton.text = if (favorites.contains(c.currentMediaItemIndex)) "♥" else "♡"
        updateProgress()
    }

    private fun updateProgress() {
        val c = controller ?: return
        val duration = c.duration.coerceAtLeast(0)
        val position = c.currentPosition.coerceAtLeast(0)
        if (!userSeeking) {
            seekBar.max = duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
            seekBar.progress = position.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        }
        currentTime.text = time(position)
        totalTime.text = if (duration > 0) time(duration) else "00:00"
    }

    private fun time(ms: Long): String {
        val seconds = (ms / 1000).coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onStart() {
        super.onStart()
        handler.post(tick)
    }

    override fun onStop() {
        handler.removeCallbacks(tick)
        super.onStop()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
